using TDARipserer, TDAPersistenceDiagrams, Statistics, LinearAlgebra, SparseArrays, Printf
import TDARipserer as PH
const DIR = @__DIR__
const DATA = joinpath(pwd(),"TDARipserer.jl/benchmark/data")
BLAS.set_num_threads(1)
function bench(f,label)
    result=f()
    times=Float64[]; bytes=Int[]
    for _ in 1:5
        GC.gc()
        t=@timed f()
        push!(times,t.time*1000); push!(bytes,t.bytes)
    end
    @printf("%s %.3f ms %.3f MiB\n",label,median(times),median(bytes)/2^20)
    flush(stdout)
    result
end
points(file,::Type{T},::Val{N}) where {T,N} = NTuple{N,T}[Tuple(parse.(T,split(s))) for s in eachline(joinpath(DATA,file))]
bars(ds)=[sort!([(birth(x),death(x)) for x in d]) for d in ds]
function savebars(name,ds)
    open(joinpath(DIR,name*".tsv"),"w") do io
        for (j,d) in enumerate(bars(ds)), (b,e) in d
            println(io, j-1,'\t',Float64(b),'\t',Float64(e))
        end
    end
end
function main()
    cloud=points("torus10k.pts", Float64,Val(3))[1:5000]
    r=.15
    a=bench(() -> Rips(cloud;threshold=r,sparse=true),"torus build pairwise sparse")
    b=bench(() -> Rips(cloud;threshold=r,radius_graph=true),"torus build indexed")
    println("torus edges ",nnz(b.adj)÷2)
    allbars=bench(() -> ripserer(cloud;threshold=r,sparse=true,dim_max=2),"torus pairwise sparse H0-H2")
    indexed=bench(() -> ripserer(cloud;threshold=r,radius_graph=true,dim_max=2),"torus indexed H0-H2")
    x=bars(allbars); y=bars(indexed)
    @assert length.(x)==length.(y) && all(all(isapprox(a,b;atol=1e-12,rtol=0) for (p,q) in zip(s,t) for (a,b) in zip(p,q)) for (s,t) in zip(x,y))
    println("torus barcode check ",length.(x))
    p=points("klein500.pts",Float64,Val(4))
    D=Float32.(PH.distances(p))
    open(io->write(io,D),joinpath(DIR,"klein.f32"),"w")
    r2=1.5f0
    for maxd in (1,2)
        ref=bench(() -> ripserer(D;dim_max=maxd,threshold=r2),"klein default H0-H"*string(maxd))
        for alg in (:redzed,)
            res=bench(() -> ripserer(D;alg,dim_max=maxd,threshold=r2),"klein "*string(alg)*" H0-H"*string(maxd))
            println("klein equal ",maxd," ",bars(ref)==bars(res))
        end
        maxd==2 && savebars("klein",ref)
    end
    im=open(joinpath(DATA,"lena1024.dipha")) do io
        header=read!(io,Vector{Int64}(undef,6))
        read!(io,Matrix{Float64}(undef,header[5],header[6]))[1:256,1:256]
    end
    open(io->write(io,im),joinpath(DIR,"lena.f64"),"w")
    ref=bench(() -> ripserer(Cubical,im;dim_max=1),"lena default H0-H1")
    opt=bench(() -> ripserer(Cubical,im;dim_max=1,alg=:cubical_union_find),"lena union find H0-H1")
    println("lena equal ",bars(opt)==bars(ref)," bars ",length.(ref)); savebars("lena",ref)
end
abspath(PROGRAM_FILE) == abspath(@__FILE__) && main()
