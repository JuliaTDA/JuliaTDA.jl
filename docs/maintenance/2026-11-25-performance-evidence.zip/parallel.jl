using Statistics, LinearAlgebra, Printf, Random
using TDAPersistenceDiagrams
import TDAmapper as M
const G=M.Graphs
const DIR=@__DIR__
BLAS.set_num_threads(1)
function bench(f,label)
    val=f()
    ts=Float64[]; bs=Float64[]
    for _ in 1:5
        GC.gc()
        t=@timed f()
        push!(ts,1000t.time); push!(bs,t.bytes/2^20)
    end
    @printf("%s %.3f ms %.3f MiB\n",label,median(ts),median(bs)); flush(stdout)
    val
end
# Prototype for covers with point IDs in 1:length(X).
function incidence_nerve(X,cover)
    g=G.SimpleGraph(length(cover))
    owners=[Int[] for _ in eachindex(X)]
    for (node,ids) in enumerate(cover), p in unique(ids)
        for other in owners[p]
            G.add_edge!(g,other,node)
        end
        push!(owners[p],node)
    end
    g
end
function gram8(k,diagrams)
    n=length(diagrams)
    G=Matrix{Float64}(undef,n,n)
    pairs=[(u,v) for v in 1:n for u in 1:v]
    Threads.@threads for l in eachindex(pairs)
        i,j=pairs[l]
        G[i,j]=G[j,i]=k(diagrams[i],diagrams[j])
    end
    G
end
function pack(ds)
    out=Array{Float64}(undef,2,length(first(ds)),length(ds))
    for (j,d) in enumerate(ds), (i,v) in enumerate(d)
        out[1,i,j]=birth(v); out[2,i,j]=death(v)
    end
    out
end
function main()
    cover=[collect(8i+1:8i+16) for i in 0:511]
    X=collect(1:last(last(cover)))
    original=bench(()->M.Nerves.make_graph(X,cover,M.Nerves.SimpleNerve()),"mapper current ($(Threads.nthreads()) threads)")
    opt=bench(()->incidence_nerve(X,cover),"mapper serial incidence")
    println("mapper equal ",original==opt," edges ",G.ne(original))
    # Heavily overlapping cover to check packed flag writes.
    overlap=[Int[1,i+1] for i in 1:96]
    xx=collect(1:97)
    ns=[G.ne(M.Nerves.make_graph(xx,overlap,M.Nerves.SimpleNerve())) for _ in 1:100]
    println("mapper complete graph expected ",binomial(96,2)," wrong out of 100 ",count(!=(binomial(96,2)),ns)," observed extrema ",extrema(ns))
    rng=MersenneTwister(25)
    diagrams=[PersistenceDiagram([(b,b+rand(rng)) for b in rand(rng,80)]) for _ in 1:48]
    k=PersistenceScaleSpaceKernel()
    gram=bench(()->kernel_matrix(k,diagrams),"gram library serial")
    par=bench(()->gram8(k,diagrams),"gram prototype ($(Threads.nthreads()) threads)")
    @assert gram==par
    arr=bench(()->pack(diagrams),"packing for GPU")
    open(io->write(io,arr),joinpath(DIR,"diagrams.f64"),"w")
    open(io->write(io,par),joinpath(DIR,"gram.f64"),"w")
end
main()
