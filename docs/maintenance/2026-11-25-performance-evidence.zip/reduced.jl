include(joinpath(@__DIR__,"core.jl"))
function compare_reduced()
    p=points("torus10k.pts",Float64,Val(3))[1:5000]
    a=bench(() -> ripserer(p;radius_graph=true,dim_max=1,threshold=.15),"torus H1 indexed cohomology")
    b=bench(() -> ripserer(p;alg=:reduced_rips,dim_max=1,threshold=.15),"torus H1 reduced Rips")
    x=bars(a); y=bars(b)
    @assert length.(x)==length.(y) && all(all(isapprox(a,b;atol=1e-12,rtol=0) for (p,q) in zip(s,t) for (a,b) in zip(p,q)) for (s,t) in zip(x,y))
    println("H1 barcode check ",length.(x))
end
compare_reduced()
