include(joinpath(@__DIR__,"core.jl"))
function o3()
    p=points("o3_1024.pts",Float64,Val(9))
    D=Float32.(PH.distances(p))
    open(io->write(io,D),joinpath(DIR,"o3.f32"),"w")
    r=1.8f0
    ref=bench(() -> ripserer(D;threshold=r,dim_max=3),"O3 default")
    for (label,fn) in [("O3 RedZeD",() -> ripserer(D;alg=:redzed,threshold=r,dim_max=3)),
                      ("O3 edge collapse",() -> ripserer(EdgeCollapsedRips,D;threshold=r,dim_max=3))]
        rr=bench(fn,label)
        @assert bars(ref)==bars(rr)
    end
    println("O3 bars ",length.(ref))
    savebars("o3",ref)
end
o3()
