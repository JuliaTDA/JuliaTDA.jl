"""Prepare the benchmark environment using the installed ecosystem manifest."""
from pathlib import Path
from shutil import copy
import re

root = Path.cwd()
bundle = Path(__file__).resolve().parent
env = bundle / "env"
env.mkdir(exist_ok=True)
umbrella = root / "JuliaTDA.jl"
copy(umbrella / "Project.toml", env / "Project.toml")

def absolutize(match):
    dep = (umbrella / match[1]).resolve()
    if dep == root / "TDARipserer.jl":
        dep = bundle / "TDARipserer"
    return 'path = "' + str(dep) + '"'

text = (umbrella / "Manifest.toml").read_text()
(env / "Manifest.toml").write_text(re.sub(r'^path = "(.*?)"$', absolutize, text, flags=re.M))
