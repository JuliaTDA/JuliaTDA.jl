from pathlib import Path
from statistics import median
from time import perf_counter
import numpy as np
import cripser
p=Path(__file__).parent
im=np.fromfile(p/'lena.f64',dtype=np.float64).reshape((256,256),order='F')
ref=np.loadtxt(p/'lena.tsv')
for loc in ['yes','none']:
    out=cripser.computePH(im,maxdim=1,top_dim=False,location=loc,n_threads=1)
    ts=[]
    for _ in range(5):
        t=perf_counter()
        out=cripser.computePH(im,maxdim=1,top_dim=False,location=loc,n_threads=1)
        ts.append((perf_counter()-t)*1000)
    triplets=out[:,:3].copy()
    triplets[triplets[:,2]==np.finfo('d').max,2]=np.inf
    def sort(arr):
        return arr[np.lexsort((arr[:,2],arr[:,1],arr[:,0]))]
    print('CubicalRipser',cripser.__version__,'locations',loc,'median',median(ts),'ms; identical',np.array_equal(sort(ref),sort(triplets)),flush=True)
