using TDARipserer, TDAPersistenceDiagrams, Statistics, LinearAlgebra, Printf, DelimitedFiles
import TDARipserer as PH
const DIR=@__DIR__
BLAS.set_num_threads(1)
D=read!(open(joinpath(DIR,"klein.f32")),Matrix{Float32}(undef,500,500))
f=Rips(D;threshold=1.5f0)
function stages(f)
    F=PH.Mod{2}
    h0=@timed PH.zeroth_intervals(f,0,false,F,false)
    m=PH.CoboundaryMatrix{true}(F,f,h0.value[2],h0.value[3])
    h1=@timed PH.compute_intervals!(m,0,false,false)
    n=@timed PH.next_matrix(m,false)
    h2=@timed PH.compute_intervals!(n.value,0,false,false)
    return 1000 .* [h0.time,h1.time,n.time,h2.time], [length(m.columns_to_reduce), length(n.value.columns_to_reduce)]
end
stages(f)
times=[(GC.gc();stages(f)) for i in 1:5]
println("stage medians ms H0, H1, H2 assembly, H2 reduction ",median(hcat(first.(times)...);dims=2)," columns ",last(times[1]))
ref=ripserer(f;dim_max=2)
bars(ds)=[sort!([(birth(x),death(x)) for x in d]) for d in ds]
function compare(f,label)
    val=f()
    @assert bars(val)==bars(ref)
    ts=Float64[]; bs=Int[]
    for _ in 1:5
        GC.gc()
        t=@timed f()
        push!(ts,1000t.time); push!(bs,t.bytes)
    end
    @printf("%s %.3f ms %.3f MiB\n",label,median(ts),median(bs)/2^20)
    flush(stdout)
end
compare(() -> ripserer(D;sparse=true,threshold=1.5f0,dim_max=2),"Klein cohomology sparse matrix filter")
compare(() -> ripserer(EdgeCollapsedRips,D;threshold=1.5f0,dim_max=2),"Klein EdgeCollapsedRips H2")
