from time import perf_counter
from pathlib import Path
from statistics import median
import numpy as np
import cupy as cp
p=Path(__file__).parent
x=np.fromfile(p/'diagrams.f64',dtype=np.float64)
ref=np.fromfile(p/'gram.f64',dtype=np.float64).reshape(48,48)
src=r'''
extern "C" __global__ void gram(const double* points, double* g, int n, int m){
    int i=blockIdx.x,j=blockIdx.y;
    if(i>j) return;
    __shared__ double scratch[256];
    double sum=0.;
    for (int k=threadIdx.x;k<m*m;k+=blockDim.x){
        int ia=2*(m*i+k/m), ib=2*(m*j+k%m);
        double b=points[ia],d=points[ia+1],a=points[ib],e=points[ib+1];
        double sq=(b-a)*(b-a)+(d-e)*(d-e);
        sum+=exp(-sq/8.)*(-expm1(-(d-b)*(e-a)/4.));
    }
    scratch[threadIdx.x]=sum;
    __syncthreads();
    for(int s=128;s>0;s>>=1){
        if(threadIdx.x<s) scratch[threadIdx.x]+=scratch[threadIdx.x+s];
        __syncthreads();
    }
    if(!threadIdx.x) g[i*n+j]=g[j*n+i]=scratch[0]/(8.*3.141592653589793);
}'''
k=cp.RawKernel(src,'gram')
def run():
    xgpu=cp.asarray(x)
    out=cp.empty((48,48),dtype=cp.float64)
    k((48,48),(256,), (xgpu,out,np.int32(48),np.int32(80)))
    return out.get()
out=run()
assert np.allclose(out,ref,rtol=1e-12,atol=1e-13), np.max(abs(out-ref))
samples=[]
for _ in range(5):
    start=perf_counter()
    run()
    samples.append(1000*(perf_counter()-start))
print('GPU synchronized host packed endpoints to host FP64 Gram:',median(samples),'ms; max abs diff',np.max(np.abs(out-ref)), 'max rel',np.max(np.abs(out-ref)/ref))
