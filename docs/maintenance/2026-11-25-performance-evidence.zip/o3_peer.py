from pathlib import Path
from time import perf_counter
from statistics import median
import numpy as np
from gph import ripser_parallel
p=Path(__file__).parent
raw=np.loadtxt(p/'o3.tsv')
D=np.fromfile(p/'o3.f32',dtype=np.float32).reshape(1024,1024)
for collapse,nt in ((False,8),(True,1),(True,8)):
    def run():
        return ripser_parallel(D,maxdim=3,thresh=np.float32(1.8),metric='precomputed',n_threads=nt,collapse_edges=collapse)['dgms']
    bars=run()
    for dim,pairs in enumerate(bars):
        ref=raw[raw[:,0]==dim,1:]
        def sort(arr):
            return arr[np.lexsort((arr[:,1], arr[:,0]))]
        assert np.array_equal(sort(pairs),sort(ref))
    ts=[]
    for _ in range(5):
        t=perf_counter(); run(); ts.append((perf_counter()-t)*1000)
    print(f'O3 giotto-ph threads={nt} collapse={collapse} {median(ts):.3f} ms; endpoints match',flush=True)
