from pathlib import Path
from time import perf_counter
from statistics import median
import numpy as np
from gph import ripser_parallel
from gudhi.sklearn import CubicalPersistence
P=Path(__file__).parent
def bench(f, label):
    ref=f(); ts=[]
    for _ in range(5):
        t=perf_counter(); val=f(); ts.append((perf_counter()-t)*1000)
    print(label, round(median(ts),3),'ms',flush=True)
    return ref
def check(diags, label):
    raw=np.loadtxt(P/(label+".tsv"))
    for dim, pairs in enumerate(diags):
        arr=raw[raw[:,0]==dim,1:]
        def sort(mat):
            return mat[np.lexsort((mat[:,1],mat[:,0]))]
        assert np.array_equal(sort(arr),sort(pairs)), (label,dim,arr.shape,pairs.shape)
    print("endpoint match",label,[len(d) for d in diags],flush=True)
D=np.fromfile(P/'klein.f32',dtype=np.float32).reshape((500,500))
for collapse in [False,True]:
    for nt in [1,8]:
        f=lambda: ripser_parallel(D,maxdim=2,thresh=1.5,metric='precomputed',n_threads=nt,collapse_edges=collapse)['dgms']
        check(bench(f, f'giotto-ph threads={nt} collapse={collapse}'),'klein')
im=np.fromfile(P/'lena.f64',dtype=np.float64).reshape((256,256),order='F')
f=lambda: CubicalPersistence(homology_dimensions=[0,1],input_type="vertices",homology_coeff_field=2,n_jobs=1).fit_transform([im])[0]
check(bench(f,"GUDHI cubical vertices"),'lena')
